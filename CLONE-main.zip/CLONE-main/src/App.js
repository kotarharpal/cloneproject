import React from 'react'
import Hotel from "./Componts/Baisic/Hotel"
import "./Componts/Baisic/Appna.css";
// import Har from './Componts/HOOKS/Har';
// import useEffect from './Componts/HOOKS/useEffect';


const App = () => {
  return (
    <>
    <div className='container'>
  
      <Hotel/>
    </div>
    </>
  );
};

export default App
