const Menu =[{
    id:1,
    image:'images/maggi.jpg',
    name:'maggi',
    Categgory:'breakfast',
    price:'12R.',
    description:'Lorem ipsum dolor sit amet consectetur adipisicing elit. Neque voluptatem provident officiis laborum nobis, optio dolorum ipsam beatae consequuntur, natus, fugit totam non? Doloribus accusantium excepturi, ipsam magnam perspiciatis saepe!'
},
{
    id:2,
    image:'images/allupakoida.jpg',
    name:'allupakoida',
    Categgory:'lunce',
    price:'19R.',
    description:'Lorem ipsum dolor sit amet consectetur adipisicing elit. Neque voluptatem provident officiis laborum nobis, optio dolorum ipsam beatae consequuntur, natus, fugit totam non? Doloribus accusantium excepturi, ipsam magnam perspiciatis saepe!'
},
{
    id:3,
    image:'images/chola.jpg',
    name:'chola',
    Categgory:'lunce',
    price:'20R.',
    description:'Lorem ipsum dolor sit amet consectetur adipisicing elit. Neque voluptatem provident officiis laborum nobis, optio dolorum ipsam beatae consequuntur, natus, fugit totam non? Doloribus accusantium excepturi, ipsam magnam perspiciatis saepe!'
},
{
    id:4,
    image:'images/corn.jpg',
    name:'corn',
    Categgory:'breakfast',
    price:'20R.',
    description:'Lorem ipsum dolor sit amet consectetur adipisicing elit. Neque voluptatem provident officiis laborum nobis, optio dolorum ipsam beatae consequuntur, natus, fugit totam non? Doloribus accusantium excepturi, ipsam magnam perspiciatis saepe!'
},
{
    id:5,
    image:'images/momo.jpg',
    name:'momo',
    Categgory:'Nasto',
    price:'200R.',
    description:'Lorem ipsum dolor sit amet consectetur adipisicing elit. Neque voluptatem provident officiis laborum nobis, optio dolorum ipsam beatae consequuntur, natus, fugit totam non? Doloribus accusantium excepturi, ipsam magnam perspiciatis saepe!'
},
{
    id:6,
    image:'images/nonvegthali.jpg',
    name:'nonvegthali',
    Categgory:'lunce',
    price:'120R.',
    description:'Lorem ipsum dolor sit amet consectetur adipisicing elit. Neque voluptatem provident officiis laborum nobis, optio dolorum ipsam beatae consequuntur, natus, fugit totam non? Doloribus accusantium excepturi, ipsam magnam perspiciatis saepe!'
},
{
    id:7,
    image:'images/paubhaji.jpg',
    name:'paubhaji',
    Categgory:'Dinner',
    price:'209R.',
    description:'Lorem ipsum dolor sit amet consectetur adipisicing elit. Neque voluptatem provident officiis laborum nobis, optio dolorum ipsam beatae consequuntur, natus, fugit totam non? Doloribus accusantium excepturi, ipsam magnam perspiciatis saepe!'
},
{
    id:8,
    image:'images/pizza.jpg',
    name:'pizza',
    Categgory:'Nasto',
    price:'203R.',
    description:'Lorem ipsum dolor sit amet consectetur adipisicing elit. Neque voluptatem provident officiis laborum nobis, optio dolorum ipsam beatae consequuntur, natus, fugit totam non? Doloribus accusantium excepturi, ipsam magnam perspiciatis saepe!'
},
{
    id:9,
    image:'images/puri.jpg',
    name:'puri',
    Categgory:'Nasto',
    price:'20R.',
    description:'Lorem ipsum dolor sit amet consectetur adipisicing elit. Neque voluptatem provident officiis laborum nobis, optio dolorum ipsam beatae consequuntur, natus, fugit totam non? Doloribus accusantium excepturi, ipsam magnam perspiciatis saepe!'
},
{
    id:10,
    image:'images/rajmarice.jpg',
    name:'rajmarice',
    Categgory:'lunce',
    price:'203R.',
    description:'Lorem ipsum dolor sit amet consectetur adipisicing elit. Neque voluptatem provident officiis laborum nobis, optio dolorum ipsam beatae consequuntur, natus, fugit totam non? Doloribus accusantium excepturi, ipsam magnam perspiciatis saepe!'
},
{
    id:11,
    image:'images/samosa.jpg',
    name:'samosa',
    Categgory:'breakfast',
    price:'23R.',
    description:'Lorem ipsum dolor sit amet consectetur adipisicing elit. Neque voluptatem provident officiis laborum nobis, optio dolorum ipsam beatae consequuntur, natus, fugit totam non? Doloribus accusantium excepturi, ipsam magnam perspiciatis saepe!'
},
{
    id:12,
    image:'images/sweet.jpg',
    name:'sweet',
    Categgory:'Dinner',
    price:'23R.',
    description:'Lorem ipsum dolor sit amet consectetur adipisicing elit. Neque voluptatem provident officiis laborum nobis, optio dolorum ipsam beatae consequuntur, natus, fugit totam non? Doloribus accusantium excepturi, ipsam magnam perspiciatis saepe!'
},
{
id:13,
image:'images/rotiwithmeat.jpg',
name:'rotiwithmeat',
Categgory:'breakfast',
price:'23R.',
description:'Lorem ipsum dolor sit amet consectetur adipisicing elit. Neque voluptatem provident officiis laborum nobis, optio dolorum ipsam beatae consequuntur, natus, fugit totam non? Doloribus accusantium excepturi, ipsam magnam perspiciatis saepe!'
},
]
export default Menu;